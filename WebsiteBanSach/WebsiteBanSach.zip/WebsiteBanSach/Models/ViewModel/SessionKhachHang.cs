﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebsiteBanSach.Models.ViewModel
{
    public static class SessionKhachHang
    {
        public static TaiKhoanKhachHang taiKhoan = null;

        public static GioHang gioHang = new GioHang();
    }
}
