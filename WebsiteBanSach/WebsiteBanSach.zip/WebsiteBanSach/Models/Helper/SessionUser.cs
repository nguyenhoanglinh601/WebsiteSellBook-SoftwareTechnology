﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebsiteBanSach.Models.Helper
{
    public static class SessionUser
    {
        public static string SessionName="_Name";
    }
}
